import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter your grade point average: ");
        double gpa = scanner.nextDouble();

        
        double credit = gpa * 10;

        
        displayStudentInfo(firstName, lastName, gpa, credit);
    }

    public static void displayStudentInfo(String firstName, String lastName, double gpa, double credit) {
        
        System.out.println("Name: " + firstName + " " + lastName);
        System.out.println("GPA: " + gpa);
        System.out.println("Bookstore Credit: $" + credit);
    }
}