import javax.swing.JOptionPane;

public class RectangleTest {
    public static void main(String[] args) {
        Rectangle rect1 = new Rectangle();

        double length = Double.parseDouble(JOptionPane.showInputDialog("Enter the length of the rectangle: "));
        double width = Double.parseDouble(JOptionPane.showInputDialog("Enter the width of the rectangle: "));

        rect1.setLength(length);
        rect1.setWidth(width);

        rect1.display();
    }
}